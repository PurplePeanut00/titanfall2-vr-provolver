# v0.3.0 — Standalone ProVolver provider (experimental)

Adds an independent campaign shot provider for Titanfall 2 VR. No bHaptics
plugin, Player or hardware is required. bHaptics can coexist for vest effects.

- Bundled Northstar client script observes ammo and emits its own shot events.
- Preserves the previously tested adaptive recoil scheduler and ProTube driver.
- Adds weapon names to diagnostics and a provider heartbeat.
- Includes setup instructions and 33 hardware-free bridge tests.

**The new game script has not yet been compiled or tested in-game.** This is a
first-test pre-release; see README and docs/VALIDATION.md for scope and limitations.

Extract the Windows ZIP, copy its game-mod/Titanfall2VR.ProVolver folder into
TF2VR/mods, obtain the ProTube DLL with GET_PROTUBE_DLL.cmd, then run START.cmd.
Test in menu 3 (monitor) before menu 2 (live recoil). The release builds the
bridge locally using Windows' included compiler. ProTube's DLL is not bundled.
