# First test — no bHaptics dependency

This is a new experimental provider. The recoil code is preserved, but the game
script needs its first in-game test before you publish it as a working release.

1. Extract `release/Titanfall2VR-ProVolver-v0.3.0-Windows.zip` somewhere new.
2. With the game closed, copy its `game-mod/Titanfall2VR.ProVolver` folder into
   your game's `TF2VR/mods` folder. Do not overwrite the whole mods folder.
3. Copy `ForceTubeVR_API_x64.dll` from your working old bridge into this new
   release folder next to START.cmd, or run GET_PROTUBE_DLL.cmd.
4. Close the old bridge and bHaptics Player. Turn on the ProVolver. Launch the
   game in VR and load your campaign save.
5. Run the new START.cmd and choose 3. Supply the `TF2VR/logs` path if asked.
   Look for "Standalone game provider detected" and shoot a few times.
6. If the Shots count rises, stop with Ctrl+C and choose 2 for live recoil.
   Restart START.cmd if Ctrl+C closed the terminal.

You can keep the bHaptics game mod installed; this version ignores its messages.
To test with it completely absent, move its mod folder and bHaptics plugin DLL
into a backup folder while the game is closed. Leave other plugins alone.

If the game reports a script error, take a screenshot. Remove only the new
Titanfall2VR.ProVolver folder to restore the previous setup.

The `repository` folder contains clean source for GitHub. Upload its contents,
including `game-mod`, only when ready. Keep DLLs and personal diagnostics out of
browser uploads. Full setup, limits and validation status are in README.md.
