# Upload this project to GitHub

Suggested repository name: **titanfall2-vr-provolver**

Suggested description:
> ProVolver recoil bridge for CircuitLord's Titanfall 2 VR mod, with a standalone shot provider and adaptive rapid-fire strength. No bHaptics required.

## 1. Create the repository

Open [GitHub's new repository page](https://github.com/new?name=titanfall2-vr-provolver).
Choose your account, enter the name and description, and choose Public if you
want other players to download it. Leave GitHub's README, licence and gitignore
initialisation options off: this package already includes them.

Click **Create repository**.

## 2. Upload the source

Open the extracted **repository** folder from this bundle. Upload its CONTENTS
to the root of the GitHub repository using **uploading an existing file** on an
empty repository, or **Add file → Upload files** on an existing one.

Include `.github`, `.gitignore`, `.gitattributes`, `tools`, `docs`, `game-mod` and all the
root files. Dragging the contents from File Explorer preserves the folders.
`README.md` and `Bridge.cs` should end up at the repository root, not inside
an extra folder called `repository`.

Use the commit message **Initial release: Titanfall 2 VR ProVolver Bridge** and
finish the upload/commit flow. If GitHub proposes a branch/PR, merge it to your
default branch to make these files the main project.

Upload the clean source folder supplied here. Do not run SDK setup inside it
before using browser upload: browser uploads do not enforce `.gitignore`.
The separate Windows release ZIP below is the version to extract for playing.
Do not upload your older personal test ZIPs, which contain the ProTube DLL.

## 3. Add a downloadable release

In your GitHub repository, open **Releases → Draft a new release** (or
**Create a new release**). Create tag **v0.3.0** on the default branch.

Title: **v0.3.0 — ProVolver recoil for Titanfall 2 VR**

Copy the text from `RELEASE_NOTES.md` in this bundle into the description.
Attach **Titanfall2VR-ProVolver-v0.3.0-Windows.zip** from the bundle's
`release` folder. Mark it as a pre-release: the new standalone game script still needs in-game
validation. See START_HERE.md before publishing it as a working release. Click **Publish release** when ready.

Upload the Windows release ZIP as the asset, not this outer GitHub bundle.
It builds the bridge locally on first launch; it is not a precompiled executable.

## Included automation

The **Actions → Build and test** workflow compiles/tests the bridge on Windows
after a push or PR, and can be started manually. It creates a downloadable
Windows ZIP artifact. It does not publish releases automatically.

The recoil scheduler and driver are unchanged, but 0.3.0 adds a new standalone
game provider that still needs testing in Titanfall 2. No bHaptics dependency.

## Licence and vendor files

The generated bridge code uses the included MIT licence. The vendor DLL is
excluded; the supplied downloader fetches the exact tested DLL from ProTube
and checks its hash. The third-party notice explains the dependency boundary.

Official GitHub references:
- https://docs.github.com/en/repositories/creating-and-managing-repositories/creating-a-new-repository
- https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository
- https://docs.github.com/en/repositories/releasing-projects-on-github/managing-releases-in-a-repository
